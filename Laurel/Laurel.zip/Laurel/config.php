<?php

class Config
{   
	static $DB_HOST = 'localhost';
	static $DB_NAME = 'laurel';
    static $DB_USER = 'root';
    static $DB_PASSWORD = '';
}